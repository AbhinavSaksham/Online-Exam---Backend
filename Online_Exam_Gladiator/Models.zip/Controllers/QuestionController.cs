﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Online_Exam_Gladiator.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Online_Exam_Gladiator.Controllers
{


    [Route("api/[controller]")]
    [ApiController]
    public class QuestionController : ControllerBase
    {
        private AppDbContext _context { get; }

        public QuestionController(AppDbContext context)
        {
            _context = context;
        }
        
        
        [HttpGet]

        public ActionResult<IEnumerable<Question>> Get()
        {
            return _context.Questions.ToList();
        }


        [HttpPost]
        
        public ActionResult<IEnumerable<Question>> Post(Question newTest)
        {
            _context.Questions.Add(newTest);
            _context.SaveChanges();
            return Ok(newTest);
        }

        [HttpGet("{id}")]
        public ActionResult<IEnumerable<Question>> Get(int? id)
        {
            if(id==null)
            {
                return BadRequest();
            }

            var data = _context.Questions.Where(data => data.Test_Id == id).ToList();
            return Ok(data);
        }

        
    }
}
