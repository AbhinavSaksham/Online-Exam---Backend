﻿using System;

namespace Online_Exam_Gladiator.Models
{
    internal class keyAttribute : Attribute
    {
    }
}